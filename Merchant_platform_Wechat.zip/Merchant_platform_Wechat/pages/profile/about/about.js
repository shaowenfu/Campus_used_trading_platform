Page({
  data: {
    appInfo: {
      name: '校园二手交易平台商家端',
      version: 'v1.0.0',
      description: '本应用是一个专注于校园二手商品交易的平台,为商家提供商品管理、订单处理等功能。',
      contact: '联系方式: admin@example.com'
    }
  }
})
